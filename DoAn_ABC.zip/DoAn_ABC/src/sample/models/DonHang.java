package sample.models;

import java.util.ArrayList;
import java.util.Date;

public class DonHang {
    private int id_mh;
    private int id_kh;
    private ArrayList ids_hang;
    private ArrayList soluongs_hang;
    private Date thoigian_mh;
    private int id_nv;


    public int getId_mh() {
        return id_mh;
    }

    public void setId_mh(int id_mh) {
        this.id_mh = id_mh;
    }

    public int getId_kh() {
        return id_kh;
    }

    public void setId_kh(int id_kh) {
        this.id_kh = id_kh;
    }

    public ArrayList getIds_hang() {
        return ids_hang;
    }

    public void setIds_hang(ArrayList ids_hang) {
        this.ids_hang = ids_hang;
    }

    public ArrayList getSoluongs_hang() {
        return soluongs_hang;
    }

    public void setSoluongs_hang(ArrayList soluongs_hang) {
        this.soluongs_hang = soluongs_hang;
    }

    public Date getThoigian_mh() {
        return thoigian_mh;
    }

    public void setThoigian_mh(Date thoigian_mh) {
        this.thoigian_mh = thoigian_mh;
    }

    public int getId_nv() {
        return id_nv;
    }

    public void setId_nv(int id_nv) {
        this.id_nv = id_nv;
    }

    public DonHang(int id_mh, int id_kh, ArrayList ids_hang, ArrayList soluongs_hang, Date thoigian_mh, int id_nv) {
        this.id_mh = id_mh;
        this.id_kh = id_kh;
        this.ids_hang = ids_hang;
        this.soluongs_hang = soluongs_hang;
        this.thoigian_mh = thoigian_mh;
        this.id_nv = id_nv;
    }

    @Override
    public String toString() {
        return "DonHang{" +
                "id_mh=" + id_mh +
                ", id_kh=" + id_kh +
                ", ids_hang=" + ids_hang +
                ", soluongs_hang=" + soluongs_hang +
                ", thoigian_mh=" + thoigian_mh +
                ", id_nv=" + id_nv +
                '}';
    }
}
