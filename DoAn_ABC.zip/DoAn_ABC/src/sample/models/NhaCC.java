package sample.models;

public class NhaCC {
    private int id_ncc;
    private String ten_ncc;
    private String quocgia_ncc;
    private String bieutuong_ncc;


    public int getId_ncc() {
        return id_ncc;
    }

    public void setId_ncc(int id_ncc) {
        this.id_ncc = id_ncc;
    }

    public String getTen_ncc() {
        return ten_ncc;
    }

    public void setTen_ncc(String ten_ncc) {
        this.ten_ncc = ten_ncc;
    }

    public String getQuocgia_ncc() {
        return quocgia_ncc;
    }

    public void setQuocgia_ncc(String quocgia_ncc) {
        this.quocgia_ncc = quocgia_ncc;
    }

    public String getBieutuong_ncc() {
        return bieutuong_ncc;
    }

    public void setBieutuong_ncc(String bieutuong_ncc) {
        this.bieutuong_ncc = bieutuong_ncc;
    }

    public NhaCC(int id_ncc, String ten_ncc, String quocgia_ncc, String bieutuong_ncc) {
        this.id_ncc = id_ncc;
        this.ten_ncc = ten_ncc;
        this.quocgia_ncc = quocgia_ncc;
        this.bieutuong_ncc = bieutuong_ncc;
    }

    @Override
    public String toString() {
        return "NhaCC{" +
                "id_ncc=" + id_ncc +
                ", ten_ncc='" + ten_ncc + '\'' +
                ", quocgia_ncc='" + quocgia_ncc + '\'' +
                ", bieutuong_ncc='" + bieutuong_ncc + '\'' +
                '}';
    }
}
